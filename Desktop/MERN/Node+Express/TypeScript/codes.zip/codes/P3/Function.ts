class App {
  test() {
    console.warn("Test function working fine");
  }
}
let a1 = new App();
a1.test();
