let no : number = 19.3;
    console.log(no);