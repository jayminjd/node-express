import sLogin from './Student';
import tLogin from './Teacher';

let s = new sLogin();
console.log(s.data);

let t = new tLogin();
console.log(t.data);

