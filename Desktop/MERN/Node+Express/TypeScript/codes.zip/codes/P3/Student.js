"use strict";
exports.__esModule = true;
var Login = /** @class */ (function () {
    function Login() {
        this.data = "Student Login done";
    }
    return Login;
}());
exports["default"] = Login;
