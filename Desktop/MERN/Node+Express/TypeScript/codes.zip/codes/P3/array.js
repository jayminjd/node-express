var games = ["cricket", "football"];
games.push("video game");
games.push(1);
games.push(true);
console.log(games);
