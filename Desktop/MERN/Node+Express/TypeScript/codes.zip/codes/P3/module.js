"use strict";
exports.__esModule = true;
var Student_1 = require("./Student");
var Teacher_1 = require("./Teacher");
var s = new Student_1["default"]();
console.log(s.data);
var t = new Teacher_1["default"]();
console.log(t.data);
