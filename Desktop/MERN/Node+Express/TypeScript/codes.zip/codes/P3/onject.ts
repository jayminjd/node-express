let student : any = {
        roll : 104,
        name : "Maulik",
        branch:"CSE",
    }
    student.name = 12 + 11 + 1998
    console.warn(student);