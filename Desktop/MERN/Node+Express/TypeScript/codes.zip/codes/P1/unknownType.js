// 3. unknown type
var userInput;
var userName;
userInput = 5;
userInput = "Max";
userName = userInput;
var userInput;
var userName;
userInput = 5;
userInput = "Max";
if (typeof userInput === "string")
    userName = userInput;
console.log(userName);
