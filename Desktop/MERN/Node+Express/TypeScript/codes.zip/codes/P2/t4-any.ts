let Activities : any[];
Activities = ["sports",true,"video game"];
Activities.push(12);
Activities.push(false);
console.warn(Activities);


