var a=[10,"jaymin"];
var[b,x]=a;
console.log(b);
console.log(x);