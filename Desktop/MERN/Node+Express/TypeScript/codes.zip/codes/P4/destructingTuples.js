"use strict";
var a = [10, "jaymin"];
var b = a[0], x = a[1];
console.log(b);
console.log(x);
