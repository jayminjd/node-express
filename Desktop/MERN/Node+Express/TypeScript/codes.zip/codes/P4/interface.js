"use strict";
var employee = {
    firstName: "jaymin",
    lastName: "darji",
    sayHi: function () { return "hello employee"; }
};
console.log("Employee object");
console.log(employee.firstName);
console.log(employee.lastName);
console.log(employee.sayHi());
var customer = {
    firstName: "urmi",
    lastName: "patel",
    sayHi: function () { return "hello customer"; }
};
console.log("customer object");
console.log(customer.firstName);
console.log(customer.lastName);
console.log(customer.sayHi());
