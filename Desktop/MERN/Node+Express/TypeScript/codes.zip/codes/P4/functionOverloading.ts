
const display=(n1:any,n2?:any)=>{
    console.log(n1);
    console.log(n2);
}
display(12);
display(12,"jaymin");